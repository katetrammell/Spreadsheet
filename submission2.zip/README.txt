Changes to model:
* We are adding a way to access the map from the interface in the model. This is neccesary because we need to get the non empty cells.
* Changed toString() in AbstractCell to make it easier to use 
* Changed toString() in our Formula class to better reflect the examples from class
* Files used in screenshots are in test > view > testFiles