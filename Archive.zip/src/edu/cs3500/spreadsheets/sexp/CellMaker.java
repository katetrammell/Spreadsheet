package edu.cs3500.spreadsheets.sexp;

import edu.cs3500.spreadsheets.model.*;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class that utilizes visitor pattern to create cells
 */
public class CellMaker implements SexpVisitor<Cell>{
  BasicSpreadsheet spread;

  public CellMaker(BasicSpreadsheet s) {
    this.spread = s;
  }
  @Override
  public Cell visitBoolean(boolean b) {
    return new BasicBooleanCell(b);
  }

  @Override
  public Cell visitNumber(double d) {

    return new BasicDoubleCell(d);
  }

  @Override
  public Cell visitSList(List<Sexp> l) {
    if (l.size() < 2) {
      throw new IllegalArgumentException(
          "need at least one symbol and two arguments");
    }
    if (!l.get(0).accept(new IsSymbol())) {
      throw new IllegalArgumentException(
          "first item is not a symbol");
    }
    SSymbol first = (SSymbol) l.get(0);
    switch (first.name) {
      case "SUM":
        SumFormula formula = new SumFormula(this.spread);
        this.addArguments(formula, l);
        return new BasicDoubleCell(formula);
      case "PRODUCT":
       ProductFormula form = new ProductFormula(this.spread);
       this.addArguments(form, l);
       return new BasicDoubleCell(form);
      case "CONCAT":
        ConcatFormula cForm = new ConcatFormula(this.spread);
        this.addArguments(cForm, l);
        return new BasicStringCell(cForm);
      case "<":
        if (l.size() != 3) {
          throw new IllegalArgumentException();
        }
        LessThanFormula lformula;
        try {
          lformula = new LessThanFormula(StringToCoord(l.get(1).toString()),
              StringToCoord(l.get(2).toString()), this.spread);
        } catch (IllegalArgumentException IAE) {
          try {
            lformula = new LessThanFormula(StringToCoord(l.get(1).toString()),
                l.get(2).accept(new CellMaker(this.spread)).getNumericValue(0), this.spread);
          } catch (Exception e1) {
            try {
              lformula = new LessThanFormula(
                  l.get(1).accept(new CellMaker(this.spread)).getNumericValue(0),
                  StringToCoord(l.get(2).toString()), this.spread);
            } catch (Exception e2) {
              try {
                lformula = new LessThanFormula(
                    l.get(1).accept(new CellMaker(this.spread)).getNumericValue(0),
                    l.get(1).accept(new CellMaker(this.spread)).getNumericValue(0), this.spread);
              } catch (Exception e3) {
                throw new IllegalArgumentException("Less than arguments invalid");
              }
            }
          }
        }


        return new BasicBooleanCell(lformula);
      default:
        throw new IllegalArgumentException("invalid symbol");
    }
  }

  /**
   * Turns strings into coordinates.
   * @param s string from file.
   * @return coordinate that reflects the information from string
   */
  private Coord StringToCoord(String s) {
    Scanner scan = new Scanner(s);
    final Pattern cellRef = Pattern.compile("([A-Za-z]+)([1-9][0-9]*)");
    scan.useDelimiter("\\s+");
    int col;
    int row;
    while (scan.hasNext("#.*")) {
      scan.nextLine();
      scan.skip("\\s*");
    }
    String cell = scan.next();
    Matcher m = cellRef.matcher(cell);
    //TODO: I think the problem may be here
    if (m.matches()) {
      col = Coord.colNameToIndex(m.group(1));
      row = Integer.parseInt(m.group(2));
    } else {
      throw new IllegalArgumentException("test");
    }
    return new Coord(col, row);
  }

  /**
   * Iterates through list of sexpressions and adds them to the given formula.
   * @param formula formula to be modified
   * @param l list of sexpressions to iterate through
   */
  private void addArguments(Formula formula, List<Sexp> l) {
    for (int i = 1; i < l.size(); i++) {
      if (l.get(i).accept(new IsSymbol())) {
        try {
          Coord c = StringToCoord(l.get(i).toString());
          formula.addCoord(c);
        } catch (IllegalArgumentException e) {
          break;
        }
      }
      else if (l.get(i).accept(new IsList())) {
        formula.addFormula(l.get(i).accept(new CellMaker(this.spread)).getFormula());
      } else {
        formula.addConstant(l.get(i).accept(new CellMaker(this.spread)).getValue());
      }
    }
  }

  @Override
  public Cell visitSymbol(String s) {
    throw new IllegalArgumentException("Can't have just a symbol");
  }

  @Override
  public Cell visitString(String s) {
    return new BasicStringCell(s);
  }
}
